import Foundation

enum ECar {
    case bmw
    case audi
}
