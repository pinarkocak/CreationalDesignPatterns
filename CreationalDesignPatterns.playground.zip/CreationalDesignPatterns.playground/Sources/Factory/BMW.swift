import Foundation

class BMW: Factory {
    func printCar(car: Car) {
        print("BMW")
    }
}
