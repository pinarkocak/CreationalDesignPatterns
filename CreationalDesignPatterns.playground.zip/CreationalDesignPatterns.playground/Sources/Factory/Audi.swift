import Foundation

class Audi: Factory {
    func printCar(car: Car) {
        print("Audi")
    }
}
