import Foundation

protocol Factory {
    func printCar(car : Car)
}
