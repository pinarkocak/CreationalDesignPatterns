import UIKit

/// Calling Factory design pattern

/* MainFactory().callFactory() */



/// Calling Prototype design pattern

/* let prototype = AddressPrototype(title: "Home", phone: "3948728", city: "Istanbul")

var homeAddress = prototype.clone()
homeAddress.printAddress()

var workAddress = prototype.clone()
workAddress.title = "Work"
workAddress.printAddress() */



/// Calling Singleton design pattern

/* PrinterObject.shared.printSingleton()
PrinterObject.shared.printSingleton() */



/// Calling Builder design pattern

let address = AddressBuilder { builder in
    builder.title = "Home"
    builder.phone = "723823747"
    builder.city = "London"
}

let myAddress = Address(builder: address)
myAddress?.printAddress()
